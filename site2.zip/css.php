<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="robots" content="index, follow"> 
<meta name="author" content="Memsidea">
<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/assets/css/assets.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/assets/css/typography.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/assets/css/shortcodes/shortcodes.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/assets/css/style.css">
<link class="skin" rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/assets/css/color/color-2.css">
<link class="skin" rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/scroll/scrollbar.css">
<link class="skin" rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/swiper/swiper.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/revolution/css/settings.css">
<link rel="stylesheet" type="text/css" href="<?php echo $ayarlar["strURL"]; ?>/assets/vendors/revolution/css/navigation.css">